# coding:utf8
import subprocess
import socket
from os import linesep


# get machine ip
def get_host_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()

    return ip


# 查找 创建cron的配置
"""
    1. /var/spool/cron/
    2. /etc/cron.d/

"""

cron_job = {}
ip = get_host_ip()

try:
    fp = open("/tmp/{0}.txt".format(ip), "a")
except IOError as e:
    exit(1)


# 扫描 root, admin, rd等账号的cron
user_cron_dir = "/var/spool/cron/"
p = subprocess.Popen("ls {0}".format(user_cron_dir), stdout=subprocess.PIPE, shell=True)
job_list = [job.strip() for job in p.stdout.read().strip().split("\n")]

for job in job_list:
    cmd_str = "grep -Ev '(titanagent|tfs_bin|tfs_inn|rsync_log_bx)' {0}{1}".format(user_cron_dir, job)
    p = subprocess.Popen(cmd_str, stdout=subprocess.PIPE, shell=True)
    cron_list = [cron.strip() for cron in p.stdout.read().strip().split(linesep)
                 if not cron.startswith("#") and cron.strip().__len__() > 0
                 ]
    if len(cron_list) == 0:
        continue
    cron_job[job] = cron_list
# print cron_job


# 扫描 /etc/cron.d/

cron_dir = "/etc/cron.d/"
excluded_file = [
    "0hourly",
    "cleanlog.cron",
    "falcon-agent",
    "openf_falcon_jvmmon",
    "openf_falcon_other_monitor.monitor",
    "openf_falcon_other_monitor",
    "sysstat",
    "tsar",
    "raid-check",
    "openf_falcon_hw_monitor",
    "openf_falcon_tfs_monitor",
    "check_troy_es",
    "openf_falcon_roma_monitor",
    "openf_falcon_mq_monitor",
    "openf_falcon_zk_monitor",
    "diamond_config_bak",
    "check_port_connections.cron",
    "openf_falcon_tfsproxy_monitor",
    "openf_falcon_tengine_monitor",
    "openf_falcon_tair_monitor"
]
p = subprocess.Popen("ls {0}".format(cron_dir), stdout=subprocess.PIPE, shell=True)
job_list = [job.strip() for job in p.stdout.read().strip().split("\n")
            if job.strip() not in excluded_file
            ]

for job in job_list:
    cmd_str = "cat {0}{1}".format(cron_dir, job)
    p = subprocess.Popen(cmd_str, stdout=subprocess.PIPE, shell=True)
    cron_list = [cron.strip() for cron in p.stdout.read().strip().split(linesep)
                 if not cron.startswith("#") and cron.strip().__len__() > 0
                 ]
    if len(cron_list) == 0:
        continue
    cron_job[job] = cron_list


hostname = subprocess.Popen("hostname", stdout=subprocess.PIPE, shell=True).stdout.read().strip()
for k, v in cron_job.iteritems():
    fp.write("{0} [{1}] \"{2}\" {3}".format(hostname, k, ' '.join(v), linesep))





