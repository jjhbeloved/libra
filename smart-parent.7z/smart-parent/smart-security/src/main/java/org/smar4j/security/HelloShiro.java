package org.smar4j.security;

/**
 * @author: YANGXUAN223
 * @date: 2018/12/9.
 */
public class HelloShiro {

    public static void main(String[] args) {
    }
}
