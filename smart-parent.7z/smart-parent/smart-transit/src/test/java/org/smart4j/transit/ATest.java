package org.smart4j.transit;

import org.junit.Test;
import org.smart4j.framework.helper.ClassHelper;

/**
 * @author: YANGXUAN223
 * @date: 2018/11/28.
 */
public class ATest {

    @Test
    public void getClassSet() {
        ClassHelper.getClassSet();
    }

}
