package org.smart4j.transit.service;

import org.smart4j.framework.annotation.Service;

/**
 * @author: YANGXUAN223
 * @date: 2018/11/29.
 */
@Service
public class CustomerService {

    public int count() {
        return 1;
    }
}
