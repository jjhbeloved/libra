package org.smart4j.framework.bean;

/**
 * @author: YANGXUAN223
 * @date: 2018/12/7.
 */
public class Data {

    private Object model;

    public Data(Object model) {
        this.model = model;
    }

    public Object getModel() {
        return model;
    }
}
